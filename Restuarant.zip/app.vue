<template>
  <div>
    <NuxtLoadingIndicator color="#ffbe0b" />
    <NuxtPage />
  </div>
</template>
